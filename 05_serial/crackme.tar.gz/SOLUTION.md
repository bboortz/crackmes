# do you want to spoiler? scroll down
```
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
```

# disassamble the binary
use objdump, ghidra, cutter, or similar tools

# unstand the function check_serial
* using a debugger
* OR using bruteforcing

# try this serial
* 9711-9796-8887-9714 
