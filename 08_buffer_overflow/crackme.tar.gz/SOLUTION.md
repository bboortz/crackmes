# find the address of the function
objdump -d output/crackme | grep -i sec
# smash the stack and insert the address of the stack
* debug compilation
```
./output/crackme < <(python -c "print('AB-'*3+'\x00'+'CD-'*3+'\x00'+'EF'*4+'\x56\x11\x40'+'\x00')")
```
* normal compilation
```
./output/crackme < <(python -c "print('AB-'*3+'\x00'+'CD-'*2+'\x00'+'E'*0+'\x90'+'\x11'+'\x40'+'\x00')")
```
