# build
```
make clean all
```

# task
* Let the crackme print "Correct password!"

# solution
* the solution can be found in SOLUTION.md


# Ref
* https://github.com/bboortz/crackmes/tree/main/08_buffer_overflow
