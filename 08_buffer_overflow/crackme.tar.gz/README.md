# build
```
make clean all
```

# task
* Let the crackme print "Right password!"

# solution
* the solution can be found in SOLUTION.md
