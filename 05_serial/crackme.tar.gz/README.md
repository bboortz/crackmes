# build
```
make clean all
```

# task
* figure out how the format of serial must look like
* create one fitting serial
* create a serial generator

You found the right serial if the crackme prints "Access granted!"

# solution
* the solution can be found in SOLUTION.md

# Ref
* https://github.com/bboortz/crackmes/tree/main/05_serial
